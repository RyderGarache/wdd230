---
title: Brightness alt high
categories:
  - UI and keyboard
tags:
  - brightness
  - sun
  - weather
---
