---
title: Check lg
categories:
  - Alerts, warnings, and signs
tags:
  - checkmark
  - confirm
  - done
---
